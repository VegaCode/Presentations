describe('hello-protractor', fucntion(){

 var ptor = protractor.getInstance();

})